package com.project.onstagram;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class OnstagramApplicationTests {

	@Test
	void contextLoads() {
	}

}
