package com.project.onstagram.service;

public interface SampleService {

}
