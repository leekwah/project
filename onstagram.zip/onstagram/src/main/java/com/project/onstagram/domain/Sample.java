package com.project.onstagram.domain;


public class Sample {

}
