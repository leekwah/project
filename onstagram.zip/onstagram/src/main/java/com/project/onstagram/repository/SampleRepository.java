package com.project.onstagram.repository;

import com.project.onstagram.domain.Sample;

public interface SampleRepository {
}
