package com.project.onstagram;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class OnstagramApplication {

	public static void main(String[] args) {
		SpringApplication.run(OnstagramApplication.class, args);
	}

}
